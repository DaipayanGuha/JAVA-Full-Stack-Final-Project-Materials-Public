package com.cg.capbook.beans;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class ProfessionalDetails {
	private String department;
	private String designation;
	private String expertise;
	@Column(nullable=true)
	private float experience;
	
	public ProfessionalDetails() {
		super();
	}
	public ProfessionalDetails(String department, String designation, String expertise, float experience) {
		super();
		this.department = department;
		this.designation = designation;
		this.expertise = expertise;
		this.experience = experience;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getExpertise() {
		return expertise;
	}
	public void setExpertise(String expertise) {
		this.expertise = expertise;
	}
	public float getExperience() {
		return experience;
	}
	public void setExperience(float experience) {
		this.experience = experience;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((department == null) ? 0 : department.hashCode());
		result = prime * result + ((designation == null) ? 0 : designation.hashCode());
		result = prime * result + Float.floatToIntBits(experience);
		result = prime * result + ((expertise == null) ? 0 : expertise.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProfessionalDetails other = (ProfessionalDetails) obj;
		if (department == null) {
			if (other.department != null)
				return false;
		} else if (!department.equals(other.department))
			return false;
		if (designation == null) {
			if (other.designation != null)
				return false;
		} else if (!designation.equals(other.designation))
			return false;
		if (Float.floatToIntBits(experience) != Float.floatToIntBits(other.experience))
			return false;
		if (expertise == null) {
			if (other.expertise != null)
				return false;
		} else if (!expertise.equals(other.expertise))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "professionalDetails [department=" + department + ", designation=" + designation + ", expertise="
				+ expertise + ", experience=" + experience + "]";
	}
		
}
