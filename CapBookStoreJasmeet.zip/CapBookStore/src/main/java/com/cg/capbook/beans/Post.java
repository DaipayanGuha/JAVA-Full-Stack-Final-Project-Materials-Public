package com.cg.capbook.beans;

import java.sql.Date;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
public class Post {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int postId;
	private String postDescription;
	private LocalDateTime postDateAndTime;
	private int postLikes=0;
	private int postDislikes=0;
	
	
	@ManyToOne
	private CapBookUser user;
	
	@OneToMany
	private List<Comments> postComments=null;
	
	public Post() {}

	public Post(String postDescription, CapBookUser user) {
		super();
		this.postDescription = postDescription;
		this.user = user;
	}

	
	public Post(String postDescription, LocalDateTime postDateAndTime, int postLikes, int postDislikes, CapBookUser user,
			List<Comments> postComments) {
		super();
		this.postDescription = postDescription;
		this.postDateAndTime = postDateAndTime;
		this.postLikes = postLikes;
		this.postDislikes = postDislikes;
		this.postComments = postComments;
		this.user = user;
		
	}

	public Post(int postId, String postDescription, LocalDateTime postDateAndTime, int postLikes, int postDislikes,
			List<Comments> postComments, CapBookUser user) {
		super();
		this.postId = postId;
		this.postDescription = postDescription;
		this.postDateAndTime = postDateAndTime;
		this.postLikes = postLikes;
		this.postDislikes = postDislikes;
		this.postComments = postComments;
		this.user = user;
	}
	

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	public String getPostDescription() {
		return postDescription;
	}

	public void setPostDescription(String postDescription) {
		this.postDescription = postDescription;
	}

	public LocalDateTime getPostDateAndTime() {
		return postDateAndTime;
	}

	public void setPostDateAndTime(LocalDateTime postDateAndTime) {
		this.postDateAndTime = postDateAndTime;
	}

	public int getPostLikes() {
		return postLikes;
	}

	public void setPostLikes(int postLikes) {
		this.postLikes = postLikes;
	}

	public int getPostDislikes() {
		return postDislikes;
	}

	public void setPostDislikes(int postDislikes) {
		this.postDislikes = postDislikes;
	}

	public CapBookUser getUser() {
		return user;
	}

	public void setUser(CapBookUser user) {
		this.user = user;
	}

	public List<Comments> getPostComments() {
		return postComments;
	}

	public void setPostComments(List<Comments> postComments) {
		this.postComments = postComments;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((postComments == null) ? 0 : postComments.hashCode());
		result = prime * result + ((postDateAndTime == null) ? 0 : postDateAndTime.hashCode());
		result = prime * result + ((postDescription == null) ? 0 : postDescription.hashCode());
		result = prime * result + postDislikes;
		result = prime * result + postId;
		result = prime * result + postLikes;
		result = prime * result + ((user == null) ? 0 : user.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Post other = (Post) obj;
		if (postComments == null) {
			if (other.postComments != null)
				return false;
		} else if (!postComments.equals(other.postComments))
			return false;
		if (postDateAndTime == null) {
			if (other.postDateAndTime != null)
				return false;
		} else if (!postDateAndTime.equals(other.postDateAndTime))
			return false;
		if (postDescription == null) {
			if (other.postDescription != null)
				return false;
		} else if (!postDescription.equals(other.postDescription))
			return false;
		if (postDislikes != other.postDislikes)
			return false;
		if (postId != other.postId)
			return false;
		if (postLikes != other.postLikes)
			return false;
		if (user == null) {
			if (other.user != null)
				return false;
		} else if (!user.equals(other.user))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Post [postId=" + postId + ", postDescription=" + postDescription + ", postDateAndTime="
				+ postDateAndTime + ", postLikes=" + postLikes + ", postDislikes=" + postDislikes + ", user=" + user
				+ ", postComments=" + postComments + "]";
	}		
}
